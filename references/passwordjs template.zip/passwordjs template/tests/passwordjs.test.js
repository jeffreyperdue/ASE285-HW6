// Make tests when you have sub functions in this module.
// passwordjs() is tested by acceptance tests (acceptance.bat)

